# -*- coding: utf-8 -*-
from odoo import fields, models, api


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        copy=False
    )

    @api.model
    def create(self, vals):
        id = super(MrpProduction, self).create(vals)
        if id.picking_ids:
            id.picking_ids.with_context(from_mrp=True).update({
                'transaction_category': id.transaction_category.id
            })
        return id

    def write(self, vals):
        super_res = super(MrpProduction, self).write(vals)
        if 'transaction_category' in vals:
            for rec in self:
                if rec.picking_ids:
                    rec.picking_ids.with_context(from_mrp=True).update({
                        'transaction_category': rec.transaction_category.id
                    })
                acc_move_lines = self.env['account.move.line'].search([('name', '=', rec.name)])
                print("11111111111111  acc_move_lines",acc_move_lines)
                acc_moves = acc_move_lines.mapped('move_id')
                print("11111111111111  acc_moves", acc_moves)

                if acc_moves:
                    acc_moves.with_context(from_mo=True).update({'transaction_category': rec.transaction_category.id})

        return super_res

