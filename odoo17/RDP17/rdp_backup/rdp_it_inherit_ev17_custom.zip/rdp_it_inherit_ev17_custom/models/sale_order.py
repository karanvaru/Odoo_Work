# -*- coding: utf-8 -*-
from odoo import fields, models, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        copy=False
    )

    @api.model
    def _update_transaction_types(self):
        if self.picking_ids:
            self.picking_ids.with_context(from_so=True).update({
                'transaction_category': self.transaction_category.id
            })
            self.picking_ids.mapped('move_ids').mapped('account_move_ids').with_context(from_so=True).update({
                'transaction_category': self.transaction_category.id
            })

    def write(self, vals):
        super_res = super(SaleOrder, self).write(vals)
        if 'transaction_category' in vals:
            if self._context.get('invoice_sale', False):
                return super_res
            for rec in self:
                for invoice in self.invoice_ids:
                    invoice.write({
                        'transaction_category': rec.transaction_category.id
                    })
                rec._update_transaction_types()
        return super_res
