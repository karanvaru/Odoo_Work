from odoo import fields, models, api, _


class CustomModel(models.Model):

    _name = 'custom.model'
    _description = 'About Custom Model'



