# -*- coding: utf-8 -*-
from odoo import fields, models, api


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        copy=False
    )

    def _prepare_invoice(self):
        res = super(PurchaseOrder, self)._prepare_invoice()
        res.update({
            'transaction_category': self.transaction_category.id
        })
        return res

    @api.model
    def _prepare_picking(self):
        vals = super(PurchaseOrder, self)._prepare_picking()
        vals.update({'transaction_category': self.transaction_category.id})
        return vals

    @api.model
    def _update_transaction_types(self):
        if self.picking_ids:
            self.picking_ids.with_context(from_po=True).update({
                'transaction_category': self.transaction_category.id
            })
            self.picking_ids.mapped('move_ids').mapped('account_move_ids').with_context(from_po=True).update({
                'transaction_category': self.transaction_category.id
            })

    def write(self, vals):
        super_res = super(PurchaseOrder, self).write(vals)
        if 'transaction_category' in vals:
            if self._context.get('invoice_purchase', False):
                return super_res
            for rec in self:
                for purchase in self.invoice_ids:
                    purchase.write({
                        'transaction_category': rec.transaction_category.id
                    })
                rec._update_transaction_types()
        return super_res
