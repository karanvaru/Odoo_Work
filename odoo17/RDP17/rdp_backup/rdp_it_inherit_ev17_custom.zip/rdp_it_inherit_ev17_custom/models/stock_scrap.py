from odoo import fields, models, api


class StockScrap(models.Model):
    _inherit = 'stock.scrap'

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        store=True,
        copy=False,
    )

    def _prepare_move_values(self):
        vals = super(StockScrap, self)._prepare_move_values()
        vals.update({
            'transaction_category': self.transaction_category.id
        })
        return vals

    def write(self, vals):
        super_res = super(StockScrap, self).write(vals)
        if 'transaction_category' in vals:
            for rec in self:
                if rec.move_id:
                    rec.move_id.with_context(from_sc=True).update({
                        'transaction_category': rec.transaction_category.id
                    })
                    if rec.move_id.account_move_ids:
                        rec.move_id.account_move_ids.with_context(from_sc=True).update({
                            'transaction_category': rec.transaction_category.id
                        })
        return super_res

    def action_validate(self):
        super_res = super(StockScrap, self).action_validate()
        self.ensure_one()
        if self.move_id:
            self.move_id.with_context(from_sc=True).update({
                'transaction_category': self.transaction_category.id
            })
            if self.move_id.account_move_ids:
                self.move_id.account_move_ids.with_context(from_sc=True).update({
                    'transaction_category': self.transaction_category.id
                })        
        return super_res
        