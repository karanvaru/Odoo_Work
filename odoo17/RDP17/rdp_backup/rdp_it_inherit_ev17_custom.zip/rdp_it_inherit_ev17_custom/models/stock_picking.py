# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class StockPicking(models.Model):
    _inherit = "stock.picking"

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        copy=False
    )

    def _write(self, vals):
        res = super(StockPicking, self)._write(vals)

        if self.move_ids_without_package:
            self.move_ids_without_package.update({'transaction_category': self.transaction_category.id})

        if self._context.get('from_mrp', False):
            return res

        if self._context.get('from_po', False):
            return res

        if self._context.get('from_so', False):
            return res

        if self._context.get('from_sc', False):
            return res

        if 'transaction_category' in vals:
            for rec in self:
                # if rec.move_ids_without_package:
                #     rec.move_ids_without_package.update({'transaction_category': rec.transaction_category.id})

                scrap = self.env['stock.scrap'].sudo().search([('picking_id', '=', rec.id)])
                if scrap:
                    scrap.update({'transaction_category': self.transaction_category})

                mrp = self.env['mrp.production'].sudo().search([('name', '=', rec.origin)])
                if mrp:
                    mrp.update({'transaction_category': self.transaction_category})
                    acc_move_lines = self.env['account.move.line'].search([('name', '=', rec.origin)])
                    acc_moves = acc_move_lines.mapped('move_id')
                    if acc_moves:
                        acc_moves.update({'transaction_category': rec.transaction_category.id})
                else:
                    if rec.purchase_id:
                        rec.purchase_id.update({'transaction_category': rec.transaction_category.id})
                        rec.purchase_id._update_transaction_types()

                    if rec.sale_id:
                        rec.sale_id.update({'transaction_category': rec.transaction_category.id})
                        rec.sale_id._update_transaction_types()

        if 'sale_id' in vals:
            for rec in self:
                if rec.sale_id.transaction_category:
                    rec.update({'transaction_category': rec.sale_id.transaction_category.id})
        return res


