# -*- coding: utf-8 -*-

from odoo import fields, models, api


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        copy=False
    )

