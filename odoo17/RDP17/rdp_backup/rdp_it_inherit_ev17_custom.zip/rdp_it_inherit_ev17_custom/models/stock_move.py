# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class StockMove(models.Model):
    _inherit = "stock.move"

    transaction_category = fields.Many2one(
        'transaction.category',
        string="Transaction Category",
        track_visibility="onchange",
        copy=False,
        reaonly=True
    )

    @api.model
    def create(self, vals):
        stock_move = super(StockMove, self).create(vals)
        if stock_move.picking_id:
            stock_move.update({
                'transaction_category': stock_move.picking_id.transaction_category.id
            })
        if not stock_move.picking_id:
            mrp = self.env['mrp.production'].sudo().search([('name', '=', stock_move.origin)])
            if mrp:
                stock_move.update({
                    'transaction_category': mrp.transaction_category.id
                })
        return stock_move
