from . import attendance_rule_config
