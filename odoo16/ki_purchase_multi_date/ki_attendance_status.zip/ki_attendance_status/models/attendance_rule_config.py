from odoo import fields, models, api, _
from odoo.exceptions import UserError
from datetime import date, datetime, time
from dateutil.relativedelta import relativedelta


class AttendanceRuleConfig(models.Model):
    _name = "attendance.rule.config"

    name = fields.Char(string="Name", required=True)
    start_time = fields.Float(string="Start Time", required=True)
    end_time = fields.Float(string="End Time", required=True)
    status_color = fields.Integer(string="Color")
    description = fields.Text(string="Description")
    company_id = fields.Many2one('res.company', string="Company", required=True, default=lambda self: self.env.company)
    active = fields.Boolean(string="Active", default=True)

    @api.constrains('end_time')
    def end_time_constrains(self):
        if self.start_time > self.end_time:
            raise UserError(_("End time must be greater then Start time."))


class HrAttendance(models.Model):
    _inherit = "hr.attendance"

    status_id = fields.Many2one(
        'attendance.rule.config',
        string="Status",

    )


class HrEmployeeEmail(models.Model):
    _inherit = "hr.employee"

    current_year = date.today().year
    current_month = date.today().strftime('%B')

    start_date = datetime.today() + relativedelta(day=1)
    End_date = datetime.today() + relativedelta(day=31)

    def _send_mail(self):
        employee_id = self.env['hr.employee'].search([])
        for rec in employee_id:
            attendance_id = self.env['hr.attendance'].search(
                [('employee_id', '=', rec.id), ('check_in', ">=", self.start_date), ('check_in', "<=", self.End_date),
                 ('check_out', ">=", self.start_date), ('check_out', "<=", self.End_date)])
            dict = {}
            for recs in attendance_id:
                if recs.status_id.name not in dict:
                    dict[recs.status_id.name] = 0
                dict[recs.status_id.name] += 1
            vals = {
                'dict': dict
            }
            mail_template = self.env.ref('ki_attendance_status.employee_email_template')
            mail_template.with_context(vals).send_mail(rec.id)
