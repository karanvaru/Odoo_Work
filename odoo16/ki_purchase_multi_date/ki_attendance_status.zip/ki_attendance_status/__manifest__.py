{
    'name': 'Ki Attendance Status',
    'version': '1.0',
    'category': 'Ki Attendance Status',
    'author': 'kiran-infosoft',
    'website': "www.kiraninfosoft.in",
    'summary': 'Ki Attendance Status',
    'description': """Ki Attendance Status""",
    'depends': ['hr_attendance'],
    'data': [
        'views/attendance_rules_config_view.xml',
        'security/ir.model.access.csv',
    ],
    'demo': [],
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
    'assets': {},
}
